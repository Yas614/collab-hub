"use client";

import React, { useState, useEffect } from "react";
import { MoreHorizontal, User, MessageSquare } from "lucide-react";
import { supabase } from "@/lib/supabase/client";
import { useRouter } from "next/navigation";
import AddTaskInline from "./AddTaskInline";

interface Task {
  id: string;
  title: string;
  description: string | null;
  column_id: string;
  position: number;
  workspace_id?: string; // Included for type precision in real-time payloads
  assigned_to?: { display_name: string | null; avatar_url: string | null } | null;
}

interface Column {
  id: string;
  title: string;
  position: number;
  workspace_id?: string;
}

interface BoardClientProps {
  workspaceId: string;
  columns: Column[];
  tasks: Task[];
}

export default function BoardClient({ workspaceId, columns, tasks }: BoardClientProps) {
  const [localTasks, setLocalTasks] = useState<Task[]>(tasks);
  const [localColumns, setLocalColumns] = useState<Column[]>(columns);
  const [draggingTaskId, setDraggingTaskId] = useState<string | null>(null);
  const [dragOverColumnId, setDragOverColumnId] = useState<string | null>(null);
  const [openMenuColumnId, setOpenMenuColumnId] = useState<string | null>(null);
  const router = useRouter();

  // Keep state perfectly balanced when Server Components re-hydrate/pass downstream data arrays
  useEffect(() => {
    setLocalTasks(tasks);
  }, [tasks]);

  useEffect(() => {
    setLocalColumns(columns);
  }, [columns]);

  // Real-time Database Event Sync Pipeline
  useEffect(() => {
    const taskChannel = supabase
      .channel(`board-realtime-${workspaceId}`)
      // 1. Listen for Task Layer shifts across teammates
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "tasks",
          filter: `workspace_id=eq.${workspaceId}`,
        },
        (payload) => {
          router.refresh(); // Sync data context seamlessly behind the scenes

          if (payload.eventType === "INSERT") {
            const newTask = payload.new as Task;
            setLocalTasks((prev) => {
              if (prev.some((t) => t.id === newTask.id)) return prev;
              return [...prev, newTask];
            });
          } else if (payload.eventType === "UPDATE") {
            const updatedTask = payload.new as Task;
            setLocalTasks((prev) =>
              prev.map((t) => (t.id === updatedTask.id ? { ...t, ...updatedTask } : t))
            );
          } else if (payload.eventType === "DELETE") {
            const deletedTask = payload.old as { id: string };
            setLocalTasks((prev) => prev.filter((t) => t.id !== deletedTask.id));
          }
        }
      )
      // 2. Listen for Column Layer updates or removals
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "columns",
          filter: `workspace_id=eq.${workspaceId}`,
        },
        (payload) => {
          router.refresh();

          if (payload.eventType === "INSERT") {
            const newCol = payload.new as Column;
            setLocalColumns((prev) => {
              if (prev.some((c) => c.id === newCol.id)) return prev;
              return [...prev, newCol].sort((a, b) => a.position - b.position);
            });
          } else if (payload.eventType === "DELETE") {
            const deletedCol = payload.old as { id: string };
            setLocalColumns((prev) => prev.filter((c) => c.id !== deletedCol.id));
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(taskChannel);
    };
  }, [workspaceId, router]);

  const handleDeleteColumn = async (columnId: string) => {
    setOpenMenuColumnId(null);
    const columnTaskCount = localTasks.filter((t) => t.column_id === columnId).length;
    const confirmMsg =
      columnTaskCount > 0
        ? `This column has ${columnTaskCount} task(s). Deleting it will delete those tasks too. Continue?`
        : "Delete this column?";
    if (!confirm(confirmMsg)) return;

    // Optimistic Column Deletion Drop
    setLocalColumns((prev) => prev.filter((c) => c.id !== columnId));
    setLocalTasks((prev) => prev.filter((t) => t.column_id !== columnId));

    const { error } = await supabase.from("columns").delete().eq("id", columnId);
    if (error) {
      console.error("Failed to delete column:", error);
      setLocalColumns(columns);
      setLocalTasks(tasks);
    } else {
      router.refresh();
    }
  };

  const handleDragStart = (taskId: string) => setDraggingTaskId(taskId);

  const handleDragOver = (e: React.DragEvent, columnId: string) => {
    e.preventDefault();
    setDragOverColumnId(columnId);
  };

  const handleDrop = async (e: React.DragEvent, columnId: string) => {
    e.preventDefault();
    setDragOverColumnId(null);

    const taskId = draggingTaskId;
    setDraggingTaskId(null);
    if (!taskId) return;

    const task = localTasks.find((t) => t.id === taskId);
    if (!task || task.column_id === columnId) return;

    const columnTasks = localTasks.filter((t) => t.column_id === columnId);
    const newPosition = columnTasks.length + 1;

    // Fast-track Optimistic UI state array re-mapping
    setLocalTasks((prev) =>
      prev.map((t) => (t.id === taskId ? { ...t, column_id: columnId, position: newPosition } : t))
    );

    const { error } = await supabase
      .from("tasks")
      .update({ column_id: columnId, position: newPosition })
      .eq("id", taskId);

    if (error) {
      console.error("Failed to move task:", error);
      setLocalTasks(tasks);
    } else {
      router.refresh();
    }
  };

  return (
    <div className="flex gap-4 overflow-x-auto pb-4 flex-1 items-start min-h-0 select-none">
      {localColumns.map((column) => {
        const columnTasks = localTasks
          .filter((task) => task.column_id === column.id)
          .sort((a, b) => a.position - b.position);
        const nextPosition = columnTasks.length + 1;
        const isDragOver = dragOverColumnId === column.id;

        return (
          <div
            key={column.id}
            onDragOver={(e) => handleDragOver(e, column.id)}
            onDragLeave={() => setDragOverColumnId(null)}
            onDrop={(e) => handleDrop(e, column.id)}
            className={`w-80 border rounded-2xl p-4 flex flex-col max-h-full shrink-0 transition-colors relative ${
              isDragOver ? "bg-indigo-50/60 border-indigo-200" : "bg-slate-50 border-slate-100"
            }`}
          >
            {/* Column Header */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-sm text-slate-800 tracking-tight">{column.title}</h3>
                <span className="text-xs font-bold text-slate-400 bg-slate-200/60 px-2 py-0.5 rounded-full">
                  {columnTasks.length}
                </span>
              </div>
              <button
                onClick={() => setOpenMenuColumnId(openMenuColumnId === column.id ? null : column.id)}
                className="text-slate-400 hover:text-slate-600 transition-colors p-1 rounded-lg relative"
              >
                <MoreHorizontal size={16} />
              </button>
              {openMenuColumnId === column.id && (
                <>
                  <div className="fixed inset-0 z-10" onClick={() => setOpenMenuColumnId(null)} />
                  <div className="absolute right-4 mt-8 bg-white border border-slate-100 rounded-xl shadow-lg z-20 py-1 w-40">
                    <button
                      onClick={() => handleDeleteColumn(column.id)}
                      className="w-full text-left px-3 py-2 text-xs font-semibold text-red-600 hover:bg-red-50 transition-colors"
                    >
                      Delete column
                    </button>
                  </div>
                </>
              )}
            </div>

            {/* Task Cards Stack */}
            <div className="space-y-3 overflow-y-auto flex-1 pr-1 custom-scrollbar min-h-[20px]">
              {columnTasks.length === 0 ? (
                <div className="border border-dashed border-slate-200 rounded-xl p-6 text-center text-xs text-slate-400 bg-white/50">
                  No tasks yet
                </div>
              ) : (
                columnTasks.map((task) => (
                  <div
                    key={task.id}
                    draggable
                    onDragStart={() => handleDragStart(task.id)}
                    onDragEnd={() => setDraggingTaskId(null)}
                    className={`bg-white border border-slate-100 p-4 rounded-xl shadow-sm hover:shadow-md transition-all cursor-grab active:cursor-grabbing space-y-3 ${
                      draggingTaskId === task.id ? "opacity-40 scale-[0.98]" : ""
                    }`}
                  >
                    <h4 className="font-semibold text-sm text-slate-800 line-clamp-2 leading-snug">{task.title}</h4>
                    {task.description && (
                      <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                        {task.description}
                      </p>
                    )}

                    <div className="flex items-center justify-between pt-2 border-t border-slate-50 text-[11px] text-slate-400">
                      <div className="flex items-center gap-1">
                        <User size={12} className="text-slate-400" />
                        <span className="truncate max-w-[120px]">{task.assigned_to?.display_name || "Unassigned"}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="flex items-center gap-1">
                          <MessageSquare size={11} />
                          0
                        </span>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            <AddTaskInline workspaceId={workspaceId} columnId={column.id} nextPosition={nextPosition} />
          </div>
        );
      })}
    </div>
  );
}