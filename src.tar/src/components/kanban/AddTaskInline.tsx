"use client";

import React, { useState } from "react";
import { Plus, X, Loader2 } from "lucide-react";
import { supabase } from "@/lib/supabase/client";
import { useRouter } from "next/navigation";

interface AddTaskInlineProps {
  workspaceId: string;
  columnId: string;
  nextPosition: number;
}

export default function AddTaskInline({ workspaceId, columnId, nextPosition }: AddTaskInlineProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [title, setTitle] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    setIsSubmitting(true);

    try {
      const { error } = await supabase
        .from("tasks")
        .insert({
          workspace_id: workspaceId,
          column_id: columnId,
          title: title.trim(),
          position: nextPosition,
        });

      if (error) throw error;

      setTitle("");
      setIsEditing(false);
      router.refresh(); // Instantly update the Server Component task list
    } catch (err) {
      console.error("Error creating task:", err);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isEditing) {
    return (
      <button 
        onClick={() => setIsEditing(true)}
        className="mt-4 w-full flex items-center justify-center gap-1.5 py-2 border border-dashed border-slate-200 hover:border-slate-300 hover:bg-white text-xs font-semibold text-slate-500 hover:text-slate-700 rounded-xl transition-all"
      >
        <Plus size={14} />
        Add Task
      </button>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="mt-4 bg-white border border-slate-100 p-3 rounded-xl shadow-sm space-y-2 animate-in fade-in duration-100">
      <input
        type="text"
        autoFocus
        required
        disabled={isSubmitting}
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Enter task title..."
        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:bg-white focus:border-indigo-400 transition-all text-slate-800"
      />
      <div className="flex items-center gap-2">
        <button
          type="submit"
          disabled={isSubmitting || !title.trim()}
          className="flex items-center gap-1 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white text-xs font-semibold px-2.5 py-1.5 rounded-lg transition-all"
        >
          {isSubmitting && <Loader2 size={12} className="animate-spin" />}
          Add
        </button>
        <button
          type="button"
          disabled={isSubmitting}
          onClick={() => setIsEditing(false)}
          className="p-1.5 hover:bg-slate-100 text-slate-400 hover:text-slate-600 rounded-lg transition-colors"
        >
          <X size={14} />
        </button>
      </div>
    </form>
  );
}