"use client";

import { useState, useRef, useEffect } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase/client";
import { Eye, EyeOff, Lock, Mail, ArrowRight, Kanban, KeyRound} from "lucide-react";

type AuthStep = "CREDENTIALS" | "VERIFY_CODE" | "NEW_PASSWORD";

const RESEND_COOLDOWN = 30;

export default function LoginPage() {
  const [step, setStep] = useState<AuthStep>("CREDENTIALS");
  const [isSignUp, setIsSignUp] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [otpDigits, setOtpDigits] = useState<string[]>(Array(6).fill(""));
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const [loading, setLoading] = useState(false);
  const [resendCooldown, setResendCooldown] = useState(0);
  const [message, setMessage] = useState<{ text: string; type: "error" | "success" | "" }>({
    text: "",
    type: "",
  });

  const otpRefs = useRef<(HTMLInputElement | null)[]>([]);
  const router = useRouter();

  useEffect(() => {
    if (resendCooldown <= 0) return;
    const t = setTimeout(() => setResendCooldown((s) => s - 1), 1000);
    return () => clearTimeout(t);
  }, [resendCooldown]);

  // --- GOOGLE LOGIN ---
  const handleGoogleLogin = async () => {
    const { error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo: `${window.location.origin}/dashboard`,
      },
    });
    if (error) setMessage({ text: error.message, type: "error" });
  };

  // --- STEP 1: LOGIN / SIGNUP TRIGGER ---
  const handleInitialSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage({ text: "", type: "" });

    if (isSignUp) {
      const { data, error } = await supabase.auth.signUp({ 
        email, 
        password,
      });

      if (error) {
        setMessage({ text: error.message, type: "error" });
      } else if (data.user) {
        setMessage({ text: "Account created! Check your email for your 6-digit code.", type: "success" });
        setStep("VERIFY_CODE");
        setResendCooldown(RESEND_COOLDOWN);
      }
    } else {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) {
        setMessage({ text: "Invalid email or password. Please try again.", type: "error" });
      } else if (data.user) {
        router.push("/dashboard");
      }
    }
    setLoading(false);
  };

  const handleForgotPasswordTrigger = async () => {
    if (!email) {
      setMessage({ text: "Please enter your email address first.", type: "error" });
      return;
    }
    setLoading(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email);
    setLoading(false);

    if (error) {
      setMessage({ text: error.message, type: "error" });
    } else {
      setMessage({ text: "Reset OTP code sent to your email!", type: "success" });
      setStep("VERIFY_CODE");
    }
  };

  // --- STEP 2: MULTI-BOX OTP LOGIC ---
  const handleOtpChange = (index: number, raw: string) => {
    const val = raw.replace(/\D/g, "").slice(-1);
    setOtpDigits((prev) => {
      const next = [...prev];
      next[index] = val;
      return next;
    });
    if (val && index < 5) otpRefs.current[index + 1]?.focus();
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    const token = otpDigits.join("");
    if (token.length !== 6) {
      setMessage({ text: "Please enter all 6 digits.", type: "error" });
      return;
    }
    setLoading(true);
    setMessage({ text: "", type: "" });

    const otpType = isSignUp ? "signup" : "recovery";

    const { data, error } = await supabase.auth.verifyOtp({
      email,
      token,
      type: otpType,
    });

    setLoading(false);

    if (error) {
      setMessage({ text: error.message, type: "error" });
    } else if (data.user) {
      if (otpType === "recovery") {
        setStep("NEW_PASSWORD");
      } else {
        router.push("/dashboard");
      }
    }
  };

  // --- STEP 3: UPDATE PASSWORD DISPATCH ---
  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      setMessage({ text: "Passwords do not match.", type: "error" });
      return;
    }
    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    setLoading(false);

    if (error) {
      setMessage({ text: error.message, type: "error" });
    } else {
      setMessage({ text: "Password changed successfully! Redirecting...", type: "success" });
      setTimeout(() => router.push("/dashboard"), 1500);
    }
  };

  return (
    <div className="flex min-h-screen bg-white font-sans text-slate-900">
      
      {/* Left Side: Modern Interactive Branding Cover */}
      <div className="hidden lg:flex w-1/2 bg-indigo-600 items-center justify-center p-12 text-white">
        <div className="max-w-md space-y-4">
          <div className="bg-white/10 w-16 h-16 rounded-2xl flex items-center justify-center backdrop-blur-md border border-white/20">
            <Kanban className="h-10 w-10" />
          </div>
          <h1 className="text-5xl font-bold tracking-tight">Manage teams with ease.</h1>
          <p className="text-indigo-100 text-lg">The all-in-one collaboration hub for modern product teams.</p>
        </div>
      </div>

      {/* Right Side: Form Shell */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 bg-slate-50/50">
        <div className="w-full max-w-md space-y-8 bg-white p-10 rounded-3xl shadow-xl shadow-slate-200/50 border border-slate-100">
          
          <div className="text-center space-y-2">
            <div className="lg:hidden flex justify-center mb-4">
              <div className="bg-indigo-600 p-3 rounded-xl text-white shadow-md">
                <Kanban className="h-6 w-6" />
              </div>
            </div>
            <h2 className="text-3xl font-extrabold tracking-tight text-slate-900">
              {step === "CREDENTIALS" ? (isSignUp ? "Get Started" : "Welcome Back") : step === "VERIFY_CODE" ? "Verification" : "New Password"}
            </h2>
            <p className="text-slate-500 text-sm">
              {step === "CREDENTIALS" ? (isSignUp ? "Create your account to start collaborating" : "Enter your details to access your workspace") : step === "VERIFY_CODE" ? `We sent a code to ${email}` : "Choose a robust replacement password below."}
            </p>
          </div>

          {/* --- STEP 1 FORM UI --- */}
          {step === "CREDENTIALS" && (
            <div className="space-y-6">
              <button
  onClick={handleGoogleLogin}
  type="button"
  className="w-full flex items-center justify-center gap-3 bg-white border border-slate-200 py-3 rounded-xl hover:bg-slate-50 transition-all font-medium text-slate-700 shadow-sm"
>
  <svg className="h-5 w-5" viewBox="0 0 24 24">
    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" />
    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
  </svg>
  Continue with Google
</button>

              <div className="relative flex items-center">
                <div className="flex-grow border-t border-slate-200"></div>
                <span className="flex-shrink mx-4 text-slate-400 text-xs uppercase tracking-widest font-semibold">Or email</span>
                <div className="flex-grow border-t border-slate-200"></div>
              </div>

              <form onSubmit={handleInitialSubmit} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-sm font-semibold text-slate-700">Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="name@company.com"
                      className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all outline-none"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between items-center">
                    <label className="text-sm font-semibold text-slate-700">Password</label>
                    <button type="button" onClick={handleForgotPasswordTrigger} className="text-xs font-semibold text-indigo-600 hover:text-indigo-700">Forgot password?</button>
                  </div>
                  <div className="relative">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                    <input
                      type={showPassword ? "text" : "password"}
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-12 pr-12 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all outline-none"
                    />
                    <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                      {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                    </button>
                  </div>
                </div>

                {message.text && (
                  <div className={`p-4 rounded-xl text-sm font-medium ${message.type === "error" ? "bg-red-50 text-red-600 border border-red-100" : "bg-emerald-50 text-emerald-700 border border-emerald-100"}`}>
                    {message.text}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 rounded-xl shadow-lg shadow-indigo-200 transition-all active:scale-[0.98] disabled:opacity-50"
                >
                  {loading ? "Please wait..." : isSignUp ? "Create Account" : "Sign In"}
                </button>
              </form>

              <p className="text-center text-sm text-slate-500">
                {isSignUp ? "Already have an account?" : "Don't have an account?"}{" "}
                <button onClick={() => { setIsSignUp(!isSignUp); setMessage({text:"", type:""}); }} className="font-bold text-indigo-600 hover:underline">
                  {isSignUp ? "Log In" : "Sign up for free"}
                </button>
              </p>
            </div>
          )}

          {/* --- STEP 2 UI: SEGMENTED 6-BOX CODE PROMPT --- */}
          {step === "VERIFY_CODE" && (
            <form onSubmit={handleVerifyOtp} className="space-y-6">
              <div className="flex justify-center gap-2">
                {otpDigits.map((digit, index) => (
                  <input
                    key={index}
                    ref={(el) => { otpRefs.current[index] = el; }}
                    type="text"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handleOtpChange(index, e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Backspace" && !digit && index > 0) {
                        otpRefs.current[index - 1]?.focus();
                      }
                    }}
                    className="w-12 h-14 text-center font-bold text-xl rounded-xl border border-slate-200 bg-slate-50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:bg-white transition-all"
                  />
                ))}
              </div>

              {message.text && (
                <div className={`p-4 rounded-xl text-sm font-medium text-center ${message.type === "error" ? "bg-red-50 text-red-600" : "bg-indigo-50 text-indigo-700"}`}>
                  {message.text}
                </div>
              )}

              <button
                type="submit"
                disabled={loading || otpDigits.join("").length !== 6}
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 rounded-xl shadow-lg shadow-indigo-200 active:scale-[0.98] transition disabled:opacity-50"
              >
                {loading ? "Verifying..." : "Verify"}
              </button>

              <button
                type="button"
                onClick={() => setStep("CREDENTIALS")}
                className="w-full text-xs font-semibold text-slate-400 hover:text-slate-600 text-center block"
              >
                ← Back to entry
              </button>
            </form>
          )}

          {/* --- STEP 3 UI: PASSWORD RESET OVERRIDE --- */}
          {step === "NEW_PASSWORD" && (
            <form onSubmit={handleUpdatePassword} className="space-y-4">
              <div className="space-y-1">
                <label className="text-sm font-semibold text-slate-700">New Password</label>
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-sm font-semibold text-slate-700">Confirm Password</label>
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all outline-none"
                />
              </div>

              {message.text && (
                <div className={`p-4 rounded-xl text-sm font-medium ${message.type === "error" ? "bg-red-50 text-red-600" : "bg-emerald-50 text-emerald-700"}`}>
                  {message.text}
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 rounded-xl shadow-lg"
              >
                {loading ? "Saving..." : "Reset Password"}
              </button>
            </form>
          )}

        </div>
      </div>
    </div>
  );
}